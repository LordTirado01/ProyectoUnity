﻿using UnityEngine;
using System.Collections;

public class statusGame : MonoBehaviour {

	public bool status;
	// Use this for initialization
	void Awake () {
	
	}
	
	// Update is called once per frame
	void Update () {
	  
		if (status == true)
		{
			guiText.text = "Jugando";
		}
		else
		{
			guiText.text = "Juego Terminado";
		}
	}
}
