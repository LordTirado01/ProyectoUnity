﻿using UnityEngine;
using System.Collections;

public class TurrentController : MonoBehaviour 
{
	private TurrentController tc1;
	public EstatusJuego estatusJuego;
	private platformCollider pcollider;
	private Vector3 mouse_pos;
	private Vector3 object_pos;
	private Vector3 worldPos;
	private float angle;
	private float bulletSpeed;
	private float distance;
	public bool gameOver=false;
	public GameObject ammo;
	private platformCollider pcol;

	public int intento=0;


	// Use this for initialization
	void Start () 
	{
		//StatusGame.status = true;
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void FixedUpdate()
	{
		mouse_pos = Input.mousePosition;
		mouse_pos.z = 0.0f;
		object_pos = Camera.main.WorldToScreenPoint (transform.position);
		object_pos.z = 0.0f;
		mouse_pos.x = mouse_pos.x - object_pos.x;	
		mouse_pos.y = mouse_pos.y - object_pos.y;
		angle = Mathf.Atan2 (mouse_pos.y, mouse_pos.x) * Mathf.Rad2Deg - 90;

		Vector3 rotationVector = new Vector3 (0, 0, angle);
		transform.rotation = Quaternion.Euler (rotationVector);

		//Disparo
			if (Input.GetMouseButtonDown (0)) {

			//si aun no he disparado...
			if (intento > 0)
			{
				object_pos = Camera.main.WorldToScreenPoint (transform.position);
				object_pos.z = 0.0f;
				worldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
				worldPos.z = 0.0f;
				tc1 = GameObject.FindGameObjectWithTag("gun").GetComponent<TurrentController>();
				tc1.transform.position = worldPos;
				intento = 0;
			}
			else
			{
				//creo al personaje como un proyectil.
				GameObject bullet = (GameObject)Instantiate (ammo, transform.position, transform.rotation);
				//el proyectil siempre sigue el puntero.
				bullet.transform.LookAt (mouse_pos);
				//mido la velocidad dependiendo de la distancia del cañon con el puntero.
				bulletSpeed = (Vector3.Distance (mouse_pos, transform.position)) * 2f;
				//calcula la fuerza y lanza el personaje.
				bullet.rigidbody2D.AddRelativeForce(bullet.transform.forward * bulletSpeed,ForceMode2D.Force); //* Time.deltaTime * 4);	
				//indicamos que ya se dio un disparo, esto para no lanzar otro personaje y no se duplique.
				intento = intento + 1;
				//reinicio la velocidad.
				bulletSpeed = 0;
			}
	    } 
	}

	void OnCollisionEnter2D(Collision2D col)
	{
		//checo si hay colision con el personaje.
		pcol = GameObject.FindGameObjectWithTag("pew").GetComponent<platformCollider>();
		pcol.Intento = intento;
		if (col.gameObject.tag == "pew") 
		{
			//indicamos al objeto del personaje que ya fue lanzado por el cañon.
			Debug.Log ("Shoooting!!");
			pcol.Disparado = false;
		}

		if (col.gameObject.tag == "Enemy") 
		{
			Debug.Log("NOOO");
			Application.LoadLevel(0);
		}
	}

}
