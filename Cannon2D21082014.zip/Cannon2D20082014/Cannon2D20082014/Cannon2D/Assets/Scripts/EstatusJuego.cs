﻿public enum EstatusJuego
{
  Disparado,
  Gana,
  Pierde
}
