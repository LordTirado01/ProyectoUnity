﻿using UnityEngine;
using System.Collections;

public class Camara : MonoBehaviour {

	public Vector3 distanciaJ;
	private TurrentController tc;
	private platformCollider pt;
	private Camera cam;
	private Transform target;

	void Awake()
	{
		/*tc = GameObject.FindGameObjectWithTag("gun").GetComponent<TurrentController>();
		cam = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
		pt = GameObject.FindGameObjectWithTag ("pew").GetComponent<platformCollider> ();
		distanciaJ = Camera.main.ScreenToWorldPoint (transform.position);
		distanciaJ.z = 0.0f;*/
		//transform.LookAt(pt.gameObject.transform.position);
		//distanciaJ = tc.gameObject.transform.position;
		//distanciaJ = Camera.main.WorldToScreenPoint (transform.position);
		//cam.transform.Translate (distanciaJ);  
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		//transform.LookAt(distanciaJ);
	}
}
