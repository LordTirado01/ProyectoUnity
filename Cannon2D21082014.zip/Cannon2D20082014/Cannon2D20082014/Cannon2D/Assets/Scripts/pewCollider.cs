﻿using UnityEngine;
using System.Collections;

public class pewCollider : MonoBehaviour {

	private statusGame StatusGame;
	// Use this for initialization
	void Start () {
		//StatusGame = GameObject.Find("Message1").GetComponent();
	}
	
	// Update is called once per frame
	void Update () {
	}

	void OnCollisionEnter2D(Collision2D col)
	{
	}
}
