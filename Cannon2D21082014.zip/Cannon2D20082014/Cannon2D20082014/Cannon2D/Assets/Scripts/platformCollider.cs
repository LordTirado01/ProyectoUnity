﻿using UnityEngine;
using System.Collections;

public class platformCollider : MonoBehaviour {

	private TurrentController tcon;
	private Vector3 mouse_pos;
	private Vector3 object_pos;
	private Vector3 worldPos;
	private bool disparado;
	private int intento;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		worldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
	}

	void OnCollisionEnter2D(Collision2D col)
	{
		if (col.gameObject.tag == "PlatformVert" ) {
						//Instantiate(StatusGame);
						//StatusGame.status = false;
						Debug.Log ("Game Over");
						//Debug.Break();
						Destroy (gameObject, 1);
						Destroy (GameObject.FindGameObjectWithTag ("gun").GetComponent<TurrentController> ());
						//disparado = true;
						Application.LoadLevel (0);
				} else if (col.gameObject.tag == "Platform") {
						Debug.Log ("LOL!!");
						Destroy (gameObject, 1);
						Destroy (GameObject.FindGameObjectWithTag ("gun").GetComponent<TurrentController> ());
						//disparado = true;
						Application.LoadLevel (0);
		        } else if (col.gameObject.tag == "Enemy") {
			            Debug.Log ("Booooooooooooooooooooooooooooooooooooomb!!");
			            Destroy (gameObject, 1);
 			            Destroy (GameObject.FindGameObjectWithTag ("gun").GetComponent<TurrentController> ());
    	        		Application.LoadLevel (0);
		        } else if (col.gameObject.tag == "Barrels") {
						Debug.Log ("EXCELENT!!");
						Destroy (gameObject, 1);
						Destroy (GameObject.FindGameObjectWithTag ("gun").GetComponent<TurrentController> ());
						//disparado = true;
						//Application.LoadLevel (0);
				}
			if (disparado == false && intento == 0) 
		{
			Debug.Log("Catched!!");
			worldPos.x = worldPos.x + 10;	
			Camera.main.transform.position = worldPos;
			Destroy (gameObject);
			//Debug.Break();
		}
		/*
		if (col.gameObject.tag == "gun" && disparado == false) 
		{
						Debug.Log ("Good!!");
						Destroy (gameObject);
						//disparado = false;
		}
		disparado = false;*/
		/* 
		else 
        {
			disparado = true;
		}*/
    }


	void FixedUpdate()
	{
		if (Input.GetMouseButtonDown (0)) 
		{
			mouse_pos = Input.mousePosition;
			mouse_pos.z = 0.0f;
			object_pos = Camera.main.WorldToScreenPoint (transform.position);
			mouse_pos.x = mouse_pos.x - object_pos.x;	
			mouse_pos.y = mouse_pos.y - object_pos.y;


			//tcon = GameObject.FindGameObjectWithTag("gun").GetComponent<TurrentController>();

			//Debug.Log ("Creado.");

		}
	}

	public bool Disparado
	{
		get {return disparado;}
		set {disparado = value;}
	}

	public int Intento
	{
		get { return intento;}
		set { intento = value;}
	}


}
